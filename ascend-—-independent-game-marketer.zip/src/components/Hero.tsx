import React from 'react';
import { ArrowDown, ArrowUpRight, ShieldCheck, Flame } from 'lucide-react';
import { GAME_IMAGES } from '../data/projectImages';

interface HeroProps {
  onViewWork: () => void;
  onOpenContact: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onViewWork, onOpenContact }) => {
  return (
    <section
      id="hero"
      className="relative min-h-[90vh] flex items-center justify-center pt-24 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      {/* Subtle cinematic background with game artwork overlays */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden select-none">
        <div className="absolute -top-32 -right-20 w-[600px] h-[600px] bg-[#3b0713]/25 rounded-full blur-[140px] opacity-70" />
        <div className="absolute top-1/2 -left-32 w-[500px] h-[500px] bg-[#141d2f]/30 rounded-full blur-[160px] opacity-60" />

        {/* Ambient subtle image montage behind the hero with dark gradient mask */}
        <div className="absolute inset-0 opacity-15 mix-blend-luminosity">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 h-full w-full p-4 transform -rotate-1 scale-105">
            <div className="overflow-hidden rounded-lg">
              <img
                src={GAME_IMAGES.gameWithBalls}
                alt="Game With Balls Preview"
                className="w-full h-full object-cover grayscale opacity-40"
              />
            </div>
            <div className="overflow-hidden rounded-lg hidden sm:block">
              <img
                src={GAME_IMAGES.necrosis}
                alt="Necrosis Preview"
                className="w-full h-full object-cover grayscale opacity-30"
              />
            </div>
            <div className="overflow-hidden rounded-lg hidden md:block">
              <img
                src={GAME_IMAGES.lirai}
                alt="Lirai Preview"
                className="w-full h-full object-cover grayscale opacity-40"
              />
            </div>
            <div className="overflow-hidden rounded-lg hidden md:block">
              <img
                src={GAME_IMAGES.artifactory}
                alt="Artifactory Preview"
                className="w-full h-full object-cover grayscale opacity-30"
              />
            </div>
          </div>
        </div>

        {/* Deep dark gradient overlay so text has 100% contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0b0b0e] via-[#0b0b0e]/92 to-[#0b0b0e]" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto text-left w-full">
        {/* Small Label */}
        <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded bg-[#131620] border border-[#23293a] text-xs font-mono tracking-widest uppercase text-[#c5a059] mb-6 sm:mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-[#5c1424] ring-2 ring-[#72192d]" />
          <span>INDEPENDENT GAME MARKETER</span>
        </div>

        {/* Large Headline */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-[5.2rem] font-extrabold tracking-tight text-white leading-[1.05] font-display mb-6 sm:mb-8 max-w-4xl">
          I HELP INDIE GAMES REACH THE RIGHT PLAYERS.
        </h1>

        {/* Short Supporting Sentence */}
        <p className="text-lg sm:text-xl md:text-2xl text-[#a2aec2] max-w-2xl font-normal leading-relaxed mb-10 sm:mb-12">
          Targeted promotion, community distribution and paid campaigns built to drive attention, traffic, wishlists and players.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 sm:gap-5 mb-14">
          <button
            id="hero-primary-cta"
            onClick={onViewWork}
            type="button"
            className="px-7 py-4 rounded-lg bg-white hover:bg-[#e4be78] text-[#090b0e] font-display font-bold text-sm tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2.5 shadow-lg group cursor-pointer"
          >
            <span>VIEW SELECTED WORK</span>
            <ArrowDown className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
          </button>

          <button
            id="hero-secondary-cta"
            onClick={onOpenContact}
            type="button"
            className="px-7 py-4 rounded-lg bg-[#141722] hover:bg-[#5c1424] text-white hover:text-white border border-[#272f42] hover:border-[#72192d] font-display font-semibold text-sm tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2.5 cursor-pointer"
          >
            <span>LET'S TALK</span>
            <ArrowUpRight className="w-4 h-4 text-[#c5a059]" />
          </button>
        </div>

        {/* Verified Data Ribbon */}
        <div className="pt-8 border-t border-[#1a1e2b] grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 font-mono">
          <div>
            <span className="text-[11px] text-[#6b7b93] uppercase tracking-wider block">
              Documented Wishlists
            </span>
            <span className="text-xl sm:text-2xl font-bold text-white tracking-tight">10,005+</span>
            <span className="text-[10px] text-[#55677d] block mt-0.5">Game With Balls</span>
          </div>

          <div>
            <span className="text-[11px] text-[#6b7b93] uppercase tracking-wider block">
              Verified Launch Clicks
            </span>
            <span className="text-xl sm:text-2xl font-bold text-white tracking-tight">19,080+</span>
            <span className="text-[10px] text-[#55677d] block mt-0.5">Tracked Direct Ingress</span>
          </div>

          <div>
            <span className="text-[11px] text-[#6b7b93] uppercase tracking-wider block">
              Audience Open Rate
            </span>
            <span className="text-xl sm:text-2xl font-bold text-[#5cff87] tracking-tight">87.7%</span>
            <span className="text-[10px] text-[#55677d] block mt-0.5">20,000 Recipients</span>
          </div>

          <div>
            <span className="text-[11px] text-[#6b7b93] uppercase tracking-wider block">
              Campaign CTR Peak
            </span>
            <span className="text-xl sm:text-2xl font-bold text-[#58a6ff] tracking-tight">69.8%</span>
            <span className="text-[10px] text-[#55677d] block mt-0.5">The Artifactory Leads</span>
          </div>
        </div>
      </div>
    </section>
  );
};
