import React, { useEffect } from 'react';
import { Project, ProofEvidence } from '../types';
import { PROOF_EVIDENCE_ITEMS } from '../data/portfolioData';
import { ProofVisualCard } from './ProofVisualCard';
import { ProjectImage } from './ProjectImage';
import { X, ExternalLink, ArrowRight, CheckCircle, ShieldCheck, ZoomIn, Layers } from 'lucide-react';

interface CaseStudyModalProps {
  project: Project | null;
  onClose: () => void;
  onInspectProof: (evidence: ProofEvidence) => void;
  onOpenImageLightbox: (src: string, title: string) => void;
  onOpenContact: () => void;
}

export const CaseStudyModal: React.FC<CaseStudyModalProps> = ({
  project,
  onClose,
  onInspectProof,
  onOpenImageLightbox,
  onOpenContact
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  const mainProof = PROOF_EVIDENCE_ITEMS.find((item) => item.id === project.proofId);
  const additionalProofs = (project.additionalProofIds || [])
    .map((id) => PROOF_EVIDENCE_ITEMS.find((item) => item.id === id))
    .filter(Boolean) as ProofEvidence[];

  return (
    <div
      id="casestudy-overlay"
      onClick={onClose}
      className="fixed inset-0 z-40 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-5 overflow-y-auto"
    >
      <div
        id="casestudy-dialog"
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-5xl my-auto bg-[#0c0e13] border border-[#232838] rounded-xl shadow-2xl overflow-hidden text-[#dce0ea] max-h-[94vh] flex flex-col"
      >
        {/* Sticky Modal Top Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between px-5 sm:px-7 py-4 bg-[#0c0e13]/95 backdrop-blur border-b border-[#1c2230]">
          <div className="flex items-center gap-3">
            <span className="text-[11px] font-mono uppercase tracking-widest px-2.5 py-1 rounded bg-[#161a26] text-[#c5a059] border border-[#262c3e]">
              CASE STUDY
            </span>
            <span className="text-xs text-[#70809b] hidden sm:inline">{project.genre}</span>
          </div>

          <button
            id="close-casestudy-btn"
            onClick={onClose}
            type="button"
            className="p-2 rounded-lg bg-[#141824] text-[#8ea0be] hover:text-white hover:bg-[#1f2536] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto px-5 sm:px-8 py-6 space-y-8">
          {/* Header Banner */}
          <div className="space-y-3">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display">
              {project.title}
            </h2>
            <p className="text-base sm:text-lg text-[#9daec7] max-w-3xl leading-relaxed">
              {project.tagline}
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs font-mono">
              <span className="px-3 py-1 rounded bg-[#171b28] text-white border border-[#252c40]">
                {project.campaignType}
              </span>
              {project.appId && (
                <span className="px-3 py-1 rounded bg-[#111622] text-[#869ab8] border border-[#1e2536]">
                  Steam App ID: {project.appId}
                </span>
              )}
            </div>
          </div>

          {/* Large Hero Artwork Banner */}
          <div
            onClick={() => onOpenImageLightbox(project.heroImage, `${project.title} — Key Visual`)}
            className="group relative w-full h-64 sm:h-80 md:h-96 rounded-xl overflow-hidden border border-[#23293b] cursor-pointer bg-[#08090d]"
          >
            <ProjectImage
              src={project.heroImage}
              fallbackSrc={project.fallbackImage}
              alt={project.title}
              genre={project.genre}
              className="group-hover:scale-102 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0c0e13] via-transparent to-transparent opacity-80 pointer-events-none" />

            <div className="absolute bottom-4 right-4 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/70 backdrop-blur text-xs text-white border border-white/10 group-hover:border-white/30 transition-colors">
              <ZoomIn className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>Click to enlarge visual</span>
            </div>

            <div className="absolute bottom-4 left-4">
              <span className="text-xs uppercase font-mono tracking-widest text-[#8a9bb2] block">
                Primary Outcome
              </span>
              <span className="text-xl sm:text-2xl font-extrabold text-white font-mono">
                {project.primaryResult}
              </span>
            </div>
          </div>

          {/* Results Metric Grid */}
          <div>
            <h3 className="text-xs font-mono uppercase tracking-widest text-[#70809b] mb-3">
              Documented Metrics
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {project.metrics.map((metric, i) => (
                <div
                  key={i}
                  className="p-4 rounded-lg bg-[#11141d] border border-[#202738] flex flex-col justify-between"
                >
                  <span className="text-[11px] font-mono text-[#71829e] uppercase tracking-wider">
                    {metric.label}
                  </span>
                  <span className="text-xl sm:text-2xl font-bold text-white font-mono mt-1 mb-1">
                    {metric.value}
                  </span>
                  <span className="text-[10px] text-[#55657f] truncate">{metric.verifiedSource}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Editorial Case Study Content */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            {/* Overview */}
            <div className="p-5 rounded-lg bg-[#11141c] border border-[#1d2331]">
              <span className="text-xs font-mono text-[#c5a059] uppercase tracking-wider block mb-2">
                Overview
              </span>
              <p className="text-sm text-[#b2c0d5] leading-relaxed">{project.overview}</p>
            </div>

            {/* Approach */}
            <div className="p-5 rounded-lg bg-[#11141c] border border-[#1d2331]">
              <span className="text-xs font-mono text-[#c5a059] uppercase tracking-wider block mb-2">
                Approach
              </span>
              <p className="text-sm text-[#b2c0d5] leading-relaxed">{project.approach}</p>
            </div>

            {/* Execution */}
            <div className="p-5 rounded-lg bg-[#11141c] border border-[#1d2331]">
              <span className="text-xs font-mono text-[#c5a059] uppercase tracking-wider block mb-2">
                Execution
              </span>
              <p className="text-sm text-[#b2c0d5] leading-relaxed">{project.execution}</p>
            </div>
          </div>

          {/* Proof Evidence Showcase */}
          <div className="space-y-4 pt-4 border-t border-[#1c2230]">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-mono text-[#5cff87] uppercase tracking-widest flex items-center gap-1.5 mb-1">
                  <ShieldCheck className="w-4 h-4" /> VERIFIED PROOF
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-white">Campaign Evidence &amp; Telemetry</h3>
              </div>
              <span className="text-xs text-[#6e7f99] hidden sm:inline">
                Click card to open full inspect view
              </span>
            </div>

            {mainProof && (
              <ProofVisualCard evidence={mainProof} onInspect={onInspectProof} />
            )}

            {additionalProofs.map((ap) => (
              <ProofVisualCard key={ap.id} evidence={ap} onInspect={onInspectProof} />
            ))}
          </div>

          {/* Bottom Action */}
          <div className="p-6 rounded-xl bg-gradient-to-r from-[#171216] via-[#12141c] to-[#12141c] border border-[#302128] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h4 className="text-lg font-bold text-white">Promote a similar game</h4>
              <p className="text-xs sm:text-sm text-[#9daec5]">
                Reach the right players with verified community and paid distribution.
              </p>
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenContact();
              }}
              type="button"
              className="px-5 py-2.5 rounded-lg bg-[#5c1424] hover:bg-[#72192d] text-white text-xs sm:text-sm font-semibold tracking-wider uppercase transition-colors flex items-center gap-2"
            >
              <span>Discuss Campaign</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
