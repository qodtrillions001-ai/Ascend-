import React, { useState, useEffect } from 'react';
import { X, Send, Check } from 'lucide-react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    gameName: '',
    steamLink: '',
    stage: 'pre-launch',
    contact: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleReset = () => {
    setFormData({
      gameName: '',
      steamLink: '',
      stage: 'pre-launch',
      contact: '',
      message: ''
    });
    setSubmitted(false);
  };

  return (
    <div
      id="contact-overlay"
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div
        id="contact-dialog"
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-xl bg-[#0e1017] border border-[#23283a] rounded-xl shadow-2xl p-6 sm:p-8 text-[#d8deeb]"
      >
        <div className="flex items-start justify-between border-b border-[#1c2233] pb-4 mb-6">
          <div>
            <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block mb-1">
              CAMPAIGN INQUIRY
            </span>
            <h3 className="text-2xl font-bold text-white font-display">
              Start a Conversation
            </h3>
            <p className="text-xs text-[#8091a9] mt-1">
              Discuss targeted promotion, Steam wishlists, and campaign timing with Ascend.
            </p>
          </div>

          <button
            onClick={onClose}
            type="button"
            className="p-2 rounded-lg bg-[#141824] text-[#8ea0be] hover:text-white hover:bg-[#1f2536] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-[#122e1b] text-[#5cff87] flex items-center justify-center mx-auto border border-[#1f5933]">
              <Check className="w-7 h-7" />
            </div>
            <h4 className="text-xl font-bold text-white font-display">Inquiry Received</h4>
            <p className="text-sm text-[#92a2ba] max-w-md mx-auto leading-relaxed">
              Thank you for sharing your game details for <strong className="text-white">{formData.gameName || 'your title'}</strong>. Your campaign inquiry has been recorded and will be reviewed alongside your Steam page.
            </p>
            <div className="pt-4 flex items-center justify-center gap-3">
              <button
                onClick={handleReset}
                type="button"
                className="px-4 py-2 rounded bg-[#161a25] hover:bg-[#202636] text-[#a4b4cc] hover:text-white text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer"
              >
                Send Another
              </button>
              <button
                onClick={onClose}
                type="button"
                className="px-5 py-2 rounded bg-white hover:bg-[#e4be78] text-[#090b0e] font-display font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs font-mono">
            <div>
              <label className="block text-[#8596ae] uppercase tracking-wider mb-1.5">
                Game / Studio Name
              </label>
              <input
                type="text"
                required
                value={formData.gameName}
                onChange={(e) => setFormData({ ...formData, gameName: e.target.value })}
                placeholder="e.g. Echoes of Ash"
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#131620] border border-[#232a3d] text-white placeholder-[#516075] focus:outline-none focus:border-[#c5a059]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[#8596ae] uppercase tracking-wider mb-1.5">
                  Steam Store or Trailer Link
                </label>
                <input
                  type="text"
                  value={formData.steamLink}
                  onChange={(e) => setFormData({ ...formData, steamLink: e.target.value })}
                  placeholder="store.steampowered.com/app/..."
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#131620] border border-[#232a3d] text-white placeholder-[#516075] focus:outline-none focus:border-[#c5a059]"
                />
              </div>

              <div>
                <label className="block text-[#8596ae] uppercase tracking-wider mb-1.5">
                  Current Stage
                </label>
                <select
                  value={formData.stage}
                  onChange={(e) => setFormData({ ...formData, stage: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#131620] border border-[#232a3d] text-white focus:outline-none focus:border-[#c5a059]"
                >
                  <option value="pre-launch">Pre-launch / Wishlists</option>
                  <option value="next-fest">Steam Next Fest Prep</option>
                  <option value="launch-window">Imminent Launch</option>
                  <option value="post-launch">Post-launch Traffic Boost</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[#8596ae] uppercase tracking-wider mb-1.5">
                Your Contact (Discord, Twitter / X, or Handle)
              </label>
              <input
                type="text"
                required
                value={formData.contact}
                onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                placeholder="e.g. Discord tag, @handle, or studio representative"
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#131620] border border-[#232a3d] text-white placeholder-[#516075] focus:outline-none focus:border-[#c5a059]"
              />
            </div>

            <div>
              <label className="block text-[#8596ae] uppercase tracking-wider mb-1.5">
                Target Audience &amp; Goals
              </label>
              <textarea
                rows={3}
                required
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Briefly describe your game genre, target players, and key marketing goals."
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#131620] border border-[#232a3d] text-white placeholder-[#516075] focus:outline-none focus:border-[#c5a059]"
              />
            </div>

            <div className="pt-3 flex items-center justify-end">
              <button
                type="submit"
                className="w-full sm:w-auto px-7 py-3 rounded-lg bg-[#5c1424] hover:bg-[#72192d] text-white font-display font-semibold tracking-wider uppercase transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>SEND INQUIRY</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
