import React from 'react';
import { Project } from '../types';
import { ArrowUpRight, ShieldCheck } from 'lucide-react';
import { ProjectImage } from './ProjectImage';

interface SelectedWorkProps {
  projects: Project[];
  onSelectProject: (project: Project) => void;
  onInspectProof: (evidenceId: string) => void;
}

export const SelectedWork: React.FC<SelectedWorkProps> = ({
  projects,
  onSelectProject,
  onInspectProof
}) => {
  return (
    <section id="work" className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#1a1d29]">
      {/* Section Header */}
      <div className="mb-12 sm:mb-16">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight font-display mb-3">
          SELECTED WORK
        </h2>
        <p className="text-sm sm:text-base text-[#8a98af] font-mono tracking-wide">
          Campaigns, experiments and measurable outcomes.
        </p>
      </div>

      {/* Asymmetrical Project Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8">
        {/* Project 1: Game With Balls (Large feature card - 7 cols) */}
        {projects[0] && (
          <div
            id={`project-card-${projects[0].id}`}
            onClick={() => onSelectProject(projects[0])}
            className="md:col-span-7 group relative bg-[#0f1118] rounded-xl border border-[#212638] hover:border-[#3b4563] transition-all duration-300 overflow-hidden cursor-pointer flex flex-col justify-between"
          >
            {/* Visual Header with Image */}
            <div className="relative h-64 sm:h-80 md:h-96 w-full overflow-hidden bg-[#0a0c10]">
              <ProjectImage
                src={projects[0].heroImage}
                fallbackSrc={projects[0].fallbackImage}
                alt={projects[0].title}
                genre={projects[0].genre}
                className="group-hover:scale-103 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f1118] via-[#0f1118]/40 to-transparent pointer-events-none" />

              {/* Tag and Steamworks Verified badge */}
              <div className="absolute top-4 left-4 flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 rounded bg-[#0a0c12]/80 backdrop-blur text-[#5cff87] border border-[#1f3f2a] flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" /> STEAMWORKS VERIFIED
                </span>
              </div>

              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between pointer-events-none">
                <div>
                  <span className="text-xs font-mono text-[#8c9bb0] uppercase tracking-wider block mb-1">
                    {projects[0].genre}
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-bold text-white font-display">
                    {projects[0].title}
                  </h3>
                </div>
                <div className="p-2.5 rounded-lg bg-white/10 group-hover:bg-[#5c1424] text-white transition-colors">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>
            </div>

            {/* Card Body */}
            <div className="p-5 sm:p-6 border-t border-[#1e2334] bg-[#0d0f16]">
              <p className="text-sm text-[#94a3bb] mb-5 leading-relaxed line-clamp-2">
                {projects[0].tagline}
              </p>

              {/* Proof Metric Row */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3 border-t border-[#1a1e2d] font-mono">
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Outstanding</span>
                  <span className="text-lg sm:text-xl font-bold text-white tracking-wide">10,005</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Additions</span>
                  <span className="text-lg sm:text-xl font-bold text-[#5cff87] tracking-wide">10,843</span>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Deletions</span>
                  <span className="text-lg sm:text-xl font-bold text-[#8f98a0] tracking-wide">&lt;8%</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Project 2: Necrosis: Dawn of Dread (5 cols) */}
        {projects[1] && (
          <div
            id={`project-card-${projects[1].id}`}
            onClick={() => onSelectProject(projects[1])}
            className="md:col-span-5 group relative bg-[#0f1118] rounded-xl border border-[#212638] hover:border-[#3b4563] transition-all duration-300 overflow-hidden cursor-pointer flex flex-col justify-between"
          >
            <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-[#0a0c10]">
              <ProjectImage
                src={projects[1].heroImage}
                fallbackSrc={projects[1].fallbackImage}
                alt={projects[1].title}
                genre={projects[1].genre}
                className="group-hover:scale-103 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f1118] via-[#0f1118]/40 to-transparent pointer-events-none" />

              <div className="absolute top-4 left-4">
                <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 rounded bg-[#0a0c12]/80 backdrop-blur text-[#8ca5cc] border border-[#232f48]">
                  VERIFIED LINK TRACKING
                </span>
              </div>

              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between pointer-events-none">
                <div>
                  <span className="text-xs font-mono text-[#8c9bb0] uppercase tracking-wider block mb-1">
                    {projects[1].genre}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
                    {projects[1].title}
                  </h3>
                </div>
                <div className="p-2.5 rounded-lg bg-white/10 group-hover:bg-[#5c1424] text-white transition-colors">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>
            </div>

            <div className="p-5 sm:p-6 border-t border-[#1e2334] bg-[#0d0f16]">
              <p className="text-sm text-[#94a3bb] mb-5 leading-relaxed line-clamp-2">
                {projects[1].tagline}
              </p>

              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-[#1a1e2d] font-mono">
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Total Clicks</span>
                  <span className="text-lg sm:text-xl font-bold text-white tracking-wide">3,990</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Peak Single Day</span>
                  <span className="text-lg sm:text-xl font-bold text-[#58a6ff] tracking-wide">2,176</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Project 3: Lirai Heir of Darkness (6 cols) */}
        {projects[2] && (
          <div
            id={`project-card-${projects[2].id}`}
            onClick={() => onSelectProject(projects[2])}
            className="md:col-span-6 group relative bg-[#0f1118] rounded-xl border border-[#212638] hover:border-[#3b4563] transition-all duration-300 overflow-hidden cursor-pointer flex flex-col justify-between"
          >
            <div className="relative h-60 sm:h-72 w-full overflow-hidden bg-[#0a0c10]">
              <ProjectImage
                src={projects[2].heroImage}
                fallbackSrc={projects[2].fallbackImage}
                alt={projects[2].title}
                genre={projects[2].genre}
                className="group-hover:scale-103 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f1118] via-[#0f1118]/40 to-transparent pointer-events-none" />

              <div className="absolute top-4 left-4">
                <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 rounded bg-[#0a0c12]/80 backdrop-blur text-[#c5a059] border border-[#3e3422]">
                  TARGETED AUDIENCE DISPATCH
                </span>
              </div>

              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between pointer-events-none">
                <div>
                  <span className="text-xs font-mono text-[#8c9bb0] uppercase tracking-wider block mb-1">
                    {projects[2].genre}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
                    {projects[2].title}
                  </h3>
                </div>
                <div className="p-2.5 rounded-lg bg-white/10 group-hover:bg-[#5c1424] text-white transition-colors">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>
            </div>

            <div className="p-5 sm:p-6 border-t border-[#1e2334] bg-[#0d0f16]">
              <p className="text-sm text-[#94a3bb] mb-5 leading-relaxed line-clamp-2">
                {projects[2].tagline}
              </p>

              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-[#1a1e2d] font-mono">
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Recipients</span>
                  <span className="text-base sm:text-lg font-bold text-white tracking-wide">20,000</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Open Rate</span>
                  <span className="text-base sm:text-lg font-bold text-[#5cff87] tracking-wide">87.7%</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Click-Through</span>
                  <span className="text-base sm:text-lg font-bold text-[#58a6ff] tracking-wide">40.0%</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Project 4: The Artifactory (6 cols) */}
        {projects[3] && (
          <div
            id={`project-card-${projects[3].id}`}
            onClick={() => onSelectProject(projects[3])}
            className="md:col-span-6 group relative bg-[#0f1118] rounded-xl border border-[#212638] hover:border-[#3b4563] transition-all duration-300 overflow-hidden cursor-pointer flex flex-col justify-between"
          >
            <div className="relative h-60 sm:h-72 w-full overflow-hidden bg-[#0a0c10]">
              <ProjectImage
                src={projects[3].heroImage}
                fallbackSrc={projects[3].fallbackImage}
                alt={projects[3].title}
                genre={projects[3].genre}
                className="group-hover:scale-103 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f1118] via-[#0f1118]/40 to-transparent pointer-events-none" />

              <div className="absolute top-4 left-4">
                <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 rounded bg-[#0a0c12]/80 backdrop-blur text-[#8ca5cc] border border-[#242f48]">
                  NICHE ENGAGEMENT DISPATCH
                </span>
              </div>

              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between pointer-events-none">
                <div>
                  <span className="text-xs font-mono text-[#8c9bb0] uppercase tracking-wider block mb-1">
                    {projects[3].genre}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
                    {projects[3].title}
                  </h3>
                </div>
                <div className="p-2.5 rounded-lg bg-white/10 group-hover:bg-[#5c1424] text-white transition-colors">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>
            </div>

            <div className="p-5 sm:p-6 border-t border-[#1e2334] bg-[#0d0f16]">
              <p className="text-sm text-[#94a3bb] mb-5 leading-relaxed line-clamp-2">
                {projects[3].tagline}
              </p>

              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-[#1a1e2d] font-mono">
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Recipients</span>
                  <span className="text-base sm:text-lg font-bold text-white tracking-wide">8,042</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Open Rate</span>
                  <span className="text-base sm:text-lg font-bold text-[#5cff87] tracking-wide">80.4%</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#6b7b92] uppercase block">Click Rate</span>
                  <span className="text-base sm:text-lg font-bold text-[#58a6ff] tracking-wide">69.8%</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
