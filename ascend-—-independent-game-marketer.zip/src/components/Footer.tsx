import React from 'react';
import { ArrowUp } from 'lucide-react';

interface FooterProps {
  onNavigateSection: (sectionId: string) => void;
  onOpenContact: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateSection, onOpenContact }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-[#1a1d29] bg-[#08090d] py-14 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <span className="font-display font-extrabold text-2xl tracking-wider text-white">
              ASCEND
            </span>
            <span className="text-xs font-mono tracking-widest text-[#a1b0c9] uppercase font-medium border-l border-[#242938] pl-3">
              GAME MARKETING
            </span>
          </div>
          <p className="text-xs text-[#7e8ea6] max-w-sm">
            Independent game marketing practice. Game promotion built around the right players.
          </p>
          <div className="text-[11px] font-mono text-[#58677c]">
            Documented campaign records and verified telemetry.
          </div>
        </div>

        {/* Links & back to top */}
        <div className="flex flex-wrap items-center gap-6 text-xs font-mono uppercase tracking-wider text-[#7989a1]">
          <button
            onClick={() => onNavigateSection('work')}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Work
          </button>
          <button
            onClick={() => onNavigateSection('services')}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Services
          </button>
          <button
            onClick={() => onNavigateSection('about')}
            className="hover:text-white transition-colors cursor-pointer"
          >
            About
          </button>
          <button
            onClick={onOpenContact}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Contact
          </button>
          <button
            onClick={scrollToTop}
            type="button"
            className="p-2 rounded-lg bg-[#12151f] hover:bg-[#1e2333] text-white border border-[#23293b] transition-colors ml-2"
            title="Back to top"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
};
