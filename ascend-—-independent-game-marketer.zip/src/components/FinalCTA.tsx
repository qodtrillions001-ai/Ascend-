import React from 'react';
import { ArrowRight, MessageSquare } from 'lucide-react';

interface FinalCTAProps {
  onOpenContact: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onOpenContact }) => {
  return (
    <section id="contact" className="py-24 sm:py-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#1a1d29]">
      <div className="relative rounded-2xl bg-[#0e1017] border border-[#202536] p-8 sm:p-14 md:p-16 overflow-hidden">
        {/* Subtle accent gradient glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#5c1424]/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block mb-4">
            NEXT STEPS
          </span>

          <h2 className="text-3xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight font-display leading-[1.08] mb-6">
            HAVE A GAME THAT NEEDS MORE PLAYERS?
          </h2>

          <p className="text-lg sm:text-xl text-[#a2b2ca] font-light leading-relaxed mb-10">
            Let's talk about where it is now, who you're trying to reach, and what we can build around it.
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mb-8">
            <button
              id="cta-start-conversation-btn"
              onClick={onOpenContact}
              type="button"
              className="px-8 py-4 rounded-lg bg-white hover:bg-[#e4be78] text-[#090b0e] font-display font-bold text-sm tracking-wider uppercase transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <span>START A CONVERSATION</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="pt-6 border-t border-[#1a1f2e] flex items-center gap-3 text-xs font-mono text-[#788ba5]">
            <MessageSquare className="w-4 h-4 text-[#c5a059]" />
            <span>Submit your game store link, current milestone, and target audience to begin.</span>
          </div>
        </div>
      </div>
    </section>
  );
};
