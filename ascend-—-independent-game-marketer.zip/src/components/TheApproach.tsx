import React from 'react';
import { APPROACH_STAGES } from '../data/portfolioData';

export const TheApproach: React.FC = () => {
  return (
    <section id="approach" className="py-20 sm:py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#1a1d29]">
      <div className="mb-12">
        <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block mb-2">
          METHODOLOGY
        </span>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display">
          THE APPROACH
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {APPROACH_STAGES.map((stage) => (
          <div
            key={stage.step}
            id={`approach-stage-${stage.step}`}
            className="p-6 sm:p-7 rounded-xl bg-[#0e1017] border border-[#202536] relative flex flex-col justify-between"
          >
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold font-mono text-[#c5a059] mb-4">
                {stage.step}
              </div>
              <h3 className="text-xl font-bold text-white font-display mb-2.5">
                {stage.title}
              </h3>
              <p className="text-sm text-[#9aa9bf] leading-relaxed">
                {stage.description}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-[#1a202d] text-[10px] font-mono uppercase tracking-widest text-[#5d6e87]">
              STAGE {stage.step} EXECUTION
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
