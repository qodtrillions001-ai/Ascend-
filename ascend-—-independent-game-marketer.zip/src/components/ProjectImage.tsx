import React, { useState } from 'react';
import { Gamepad2 } from 'lucide-react';

interface ProjectImageProps {
  src: string;
  alt: string;
  fallbackSrc?: string;
  className?: string;
  containerClassName?: string;
  genre?: string;
}

export const ProjectImage: React.FC<ProjectImageProps> = ({
  src,
  alt,
  fallbackSrc,
  className = '',
  containerClassName = '',
  genre
}) => {
  const isDataUri = typeof src === 'string' && src.startsWith('data:');
  const [currentSrc, setCurrentSrc] = useState<string>(src);
  const [hasError, setHasError] = useState<boolean>(false);
  const [isLoaded, setIsLoaded] = useState<boolean>(isDataUri);

  // Sync if prop changes
  React.useEffect(() => {
    setCurrentSrc(src);
    setHasError(false);
    setIsLoaded(typeof src === 'string' && src.startsWith('data:'));
  }, [src]);

  const handleError = () => {
    if (fallbackSrc && currentSrc !== fallbackSrc) {
      // Attempt fallback path
      setCurrentSrc(fallbackSrc);
    } else {
      setHasError(true);
    }
  };

  return (
    <div className={`relative w-full h-full overflow-hidden bg-[#0a0c10] ${containerClassName}`}>
      {/* Loading shimmer placeholder */}
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 bg-gradient-to-r from-[#0d0f16] via-[#161a25] to-[#0d0f16] animate-pulse" />
      )}

      {!hasError ? (
        <img
          src={currentSrc}
          alt={alt}
          loading="eager"
          onLoad={() => setIsLoaded(true)}
          onError={handleError}
          className={`w-full h-full object-cover object-center transition-all duration-700 ${
            isLoaded ? 'opacity-90' : 'opacity-0'
          } ${className}`}
        />
      ) : (
        /* Styled fallback art card if network completely blocks binary files */
        <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#121520] via-[#0d0f17] to-[#1a121e]">
          <div className="w-12 h-12 rounded-xl bg-[#1c2233] border border-[#2b354d] text-[#c5a059] flex items-center justify-center mb-3">
            <Gamepad2 className="w-6 h-6" />
          </div>
          <span className="text-white font-display font-bold text-lg tracking-wide mb-1">
            {alt}
          </span>
          {genre && (
            <span className="text-[11px] font-mono text-[#8b9cb5] uppercase tracking-wider">
              {genre}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
