import React from 'react';
import { ArrowUpRight } from 'lucide-react';

interface AboutSectionProps {
  onOpenContact: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onOpenContact }) => {
  return (
    <section id="about" className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#1a1d29]">
      <div className="max-w-4xl">
        <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block mb-2">
          INDEPENDENT PRACTICE
        </span>
        <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display mb-8">
          ABOUT ASCEND
        </h2>

        {/* Short, direct, confident copy */}
        <div className="space-y-6 text-base sm:text-xl text-[#b2c0d5] leading-relaxed font-light">
          <p>
            <strong className="text-white font-medium">Ascend</strong> is an independent game marketing practice working directly with indie game developers and small publisher teams to build targeted attention, traffic surges, and measurable Steam player acquisition.
          </p>
          <p>
            Rather than relying on generic agency retainers or vanity social metrics, every campaign is built around reaching the specific players already proven to play and purchase games in your genre.
          </p>
        </div>

        {/* Direct engagement attributes */}
        <div className="mt-10 pt-8 border-t border-[#1c2231] grid grid-cols-1 sm:grid-cols-3 gap-6 font-mono text-xs">
          <div>
            <span className="text-[#64748d] uppercase block mb-1">Structure</span>
            <span className="text-white font-medium text-sm">Direct Collaboration</span>
            <p className="text-[#7d8ea6] text-[11px] mt-0.5">No agency bureaucracy or middle layers</p>
          </div>

          <div>
            <span className="text-[#64748d] uppercase block mb-1">Focus</span>
            <span className="text-white font-medium text-sm">Indie &amp; Steam Games</span>
            <p className="text-[#7d8ea6] text-[11px] mt-0.5">Engineered for algorithm visibility</p>
          </div>

          <div>
            <span className="text-[#64748d] uppercase block mb-1">Measurement</span>
            <span className="text-white font-medium text-sm">Verified Telemetry</span>
            <p className="text-[#7d8ea6] text-[11px] mt-0.5">Wishlists, traffic curves, open rates</p>
          </div>
        </div>
      </div>
    </section>
  );
};
