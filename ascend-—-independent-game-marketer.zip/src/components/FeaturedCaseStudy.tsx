import React, { useState } from 'react';
import { Project, ProofEvidence } from '../types';
import { PROOF_EVIDENCE_ITEMS } from '../data/portfolioData';
import { ProofVisualCard } from './ProofVisualCard';
import { ProjectImage } from './ProjectImage';
import { ArrowRight, ShieldCheck, ZoomIn, CheckCircle2 } from 'lucide-react';

interface FeaturedCaseStudyProps {
  project: Project;
  onOpenCaseStudy: (project: Project) => void;
  onInspectProof: (evidence: ProofEvidence) => void;
  onOpenImageLightbox: (src: string, title: string) => void;
}

export const FeaturedCaseStudy: React.FC<FeaturedCaseStudyProps> = ({
  project,
  onOpenCaseStudy,
  onInspectProof,
  onOpenImageLightbox
}) => {
  const proofEvidence = PROOF_EVIDENCE_ITEMS.find((p) => p.id === project.proofId) || PROOF_EVIDENCE_ITEMS[0];

  return (
    <section
      id="featured-case-study"
      className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#1a1d29]"
    >
      <div className="mb-8">
        <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block mb-2">
          FLAGSHIP CASE STUDY
        </span>
        <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display">
          {project.title}
        </h2>
        <p className="text-base sm:text-lg text-[#95a5bd] max-w-3xl mt-2">
          {project.tagline}
        </p>
      </div>

      {/* The Campaign Section */}
      <div className="mb-10 p-6 sm:p-8 rounded-xl bg-[#0e1017] border border-[#202636] relative overflow-hidden">
        <div className="max-w-3xl">
          <h3 className="text-xs font-mono uppercase tracking-widest text-[#8598b4] mb-3">
            THE CAMPAIGN
          </h3>
          <p className="text-base sm:text-lg text-[#d2d9e6] leading-relaxed">
            {project.overview} Targeted discovery was concentrated on players with documented affinity for physics-based mechanics, converting community attention directly into active Steam wishlist bookmarks ahead of release with a verified 92.3% retention rate.
          </p>
        </div>

        {/* Small Results Row: TRAFFIC / WISHLISTS / REACH */}
        <div className="mt-8 pt-6 border-t border-[#1b212f] grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 font-mono">
          <div>
            <span className="text-[11px] text-[#6d7e97] uppercase tracking-wider block">
              WISHLISTS
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-[#5cff87] tracking-tight">
              10,005
            </span>
            <span className="text-[10px] text-[#55677d] block mt-0.5">Current Outstanding</span>
          </div>

          <div>
            <span className="text-[11px] text-[#6d7e97] uppercase tracking-wider block">
              ADDITIONS
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              10,843
            </span>
            <span className="text-[10px] text-[#55677d] block mt-0.5">Verified Gross Additions</span>
          </div>

          <div>
            <span className="text-[11px] text-[#6d7e97] uppercase tracking-wider block">
              RETENTION
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-[#58a6ff] tracking-tight">
              92.3%
            </span>
            <span className="text-[10px] text-[#55677d] block mt-0.5">837 deletions lifetime</span>
          </div>

          <div>
            <span className="text-[11px] text-[#6d7e97] uppercase tracking-wider block">
              FIRST WISHLIST
            </span>
            <span className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              2025-06-09
            </span>
            <span className="text-[10px] text-[#55677d] block mt-0.5">Steamworks Log</span>
          </div>
        </div>
      </div>

      {/* The Hero of the Case Study: The Proof Dashboard */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-[#5cff87] uppercase tracking-widest flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" /> OFFICIAL EVIDENCE
            </span>
            <span className="text-xs text-[#6e7f99] hidden sm:inline">
              Steamworks Partner Telemetry
            </span>
          </div>
          <button
            onClick={() => onOpenCaseStudy(project)}
            type="button"
            className="text-xs font-mono uppercase tracking-wider text-[#c5a059] hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <span>Open Full Case Study</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Large Interactive Proof Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8">
            <ProofVisualCard evidence={proofEvidence} onInspect={onInspectProof} />
          </div>

          {/* Secondary Game Key Art */}
          <div
            onClick={() => onOpenImageLightbox(project.heroImage, `${project.title} — Key Art`)}
            className="lg:col-span-4 group relative h-72 sm:h-80 lg:h-[370px] rounded-lg overflow-hidden border border-[#23293b] cursor-pointer bg-[#0c0e14]"
          >
            <ProjectImage
              src={project.heroImage}
              fallbackSrc={project.fallbackImage}
              alt={project.title}
              genre={project.genre}
              className="group-hover:scale-103 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0c0e14] via-transparent to-transparent opacity-70 pointer-events-none" />
            <div className="absolute bottom-4 left-4 right-4 pointer-events-none">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#97a8be] block">
                Key Visual
              </span>
              <span className="text-lg font-bold text-white font-display">
                {project.title}
              </span>
            </div>
            <div className="absolute top-4 right-4 p-2 rounded-lg bg-black/60 backdrop-blur text-white border border-white/10 group-hover:border-white/30 transition-colors">
              <ZoomIn className="w-4 h-4 text-[#c5a059]" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
