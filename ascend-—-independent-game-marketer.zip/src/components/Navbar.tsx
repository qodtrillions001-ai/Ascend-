import React, { useState, useEffect } from 'react';
import { ArrowUpRight, Menu, X } from 'lucide-react';

interface NavbarProps {
  onOpenContact: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenContact, onNavigateSection }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (sectionId: string) => {
    onNavigateSection(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-30 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#090a0d]/90 backdrop-blur-md border-b border-[#1c1f2b] py-3.5 shadow-lg'
          : 'bg-transparent py-5 sm:py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo / Name */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="group text-left flex items-baseline gap-2.5 focus:outline-none cursor-pointer"
        >
          <span className="font-display font-extrabold text-xl sm:text-2xl tracking-wider text-white group-hover:text-[#e4be78] transition-colors">
            ASCEND
          </span>
          <span className="text-[10px] font-mono tracking-widest text-[#a1b0c9] uppercase font-medium border-l border-[#272b3a] pl-2.5 hidden sm:inline">
            GAME MARKETING
          </span>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-xs font-mono tracking-widest uppercase text-[#9ea8ba]">
          <button
            id="nav-work-btn"
            onClick={() => handleNavClick('work')}
            className="hover:text-white transition-colors cursor-pointer py-1"
          >
            WORK
          </button>
          <button
            id="nav-services-btn"
            onClick={() => handleNavClick('services')}
            className="hover:text-white transition-colors cursor-pointer py-1"
          >
            SERVICES
          </button>
          <button
            id="nav-about-btn"
            onClick={() => handleNavClick('about')}
            className="hover:text-white transition-colors cursor-pointer py-1"
          >
            ABOUT
          </button>
          <button
            id="nav-contact-btn"
            onClick={onOpenContact}
            className="px-3.5 py-1.5 rounded bg-[#141722] hover:bg-[#5c1424] hover:text-white text-white border border-[#252c3e] transition-all cursor-pointer flex items-center gap-1.5"
          >
            <span>CONTACT</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-[#c5a059]" />
          </button>
        </nav>

        {/* Mobile menu trigger */}
        <button
          id="mobile-nav-toggle"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-[#9ea8ba] hover:text-white focus:outline-none"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0a0c10] border-b border-[#1f2433] px-6 py-6 space-y-4 font-mono text-sm uppercase tracking-widest">
          <button
            onClick={() => handleNavClick('work')}
            className="block w-full text-left py-2 text-[#b0bac9] hover:text-white"
          >
            WORK
          </button>
          <button
            onClick={() => handleNavClick('services')}
            className="block w-full text-left py-2 text-[#b0bac9] hover:text-white"
          >
            SERVICES
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className="block w-full text-left py-2 text-[#b0bac9] hover:text-white"
          >
            ABOUT
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenContact();
            }}
            className="block w-full text-left py-2.5 text-[#e4be78] font-bold"
          >
            CONTACT &rarr;
          </button>
        </div>
      )}
    </header>
  );
};
