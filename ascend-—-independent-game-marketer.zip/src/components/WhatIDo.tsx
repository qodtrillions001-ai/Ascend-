import React from 'react';
import { SERVICES } from '../data/portfolioData';

export const WhatIDo: React.FC = () => {
  return (
    <section id="services" className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#1a1d29]">
      <div className="mb-12">
        <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block mb-2">
          CAPABILITIES
        </span>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display">
          WHAT I DO
        </h2>
      </div>

      {/* 6 Compact items in a clean grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {SERVICES.map((item, index) => (
          <div
            key={index}
            id={`service-item-${index}`}
            className="p-6 rounded-xl bg-[#0f1118] border border-[#202536] hover:border-[#38435f] transition-colors"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-mono tracking-widest uppercase px-2 py-0.5 rounded bg-[#161a25] text-[#8ea2c4] border border-[#232a3d]">
                {item.tag}
              </span>
              <span className="text-xs font-mono text-[#54647c]">0{index + 1}</span>
            </div>

            <h3 className="text-lg font-bold text-white font-display mb-2">
              {item.title}
            </h3>

            <p className="text-sm text-[#9aa9bf] leading-relaxed">
              {item.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
};
