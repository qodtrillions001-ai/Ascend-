import React from 'react';
import { ProofEvidence } from '../types';
import { ExternalLink, CheckCircle2, ShieldCheck, ZoomIn, ArrowUpRight, BarChart3, Mail, Gamepad2 } from 'lucide-react';

interface ProofVisualCardProps {
  evidence: ProofEvidence;
  onInspect?: (evidence: ProofEvidence) => void;
  className?: string;
  isCompact?: boolean;
}

export const ProofVisualCard: React.FC<ProofVisualCardProps> = ({
  evidence,
  onInspect,
  className = '',
  isCompact = false
}) => {
  const { id, type, title, subtitle, sourceLabel, date, data } = evidence;

  const handleInspect = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onInspect) {
      onInspect(evidence);
    }
  };

  if (type === 'steamworks') {
    return (
      <div
        id={id}
        onClick={handleInspect}
        className={`group relative bg-[#171d25] border border-[#2a3844] rounded-lg p-4 sm:p-5 font-sans text-[#c6d4df] transition-all hover:border-[#417a9b] cursor-pointer shadow-xl ${className}`}
      >
        <div className="flex items-center justify-between border-b border-[#253241] pb-3 mb-4">
          <div className="flex items-center gap-2 text-xs font-mono text-[#67c1f5]">
            <span className="inline-block w-2 h-2 rounded-full bg-[#5cff67] animate-pulse"></span>
            <span>STEAMWORKS OFFICIAL PARTNER TELEMETRY</span>
          </div>
          <button
            type="button"
            className="flex items-center gap-1.5 text-xs text-[#8f98a0] group-hover:text-white px-2 py-1 rounded bg-[#10141a] border border-[#232c37] transition-colors"
          >
            <ZoomIn className="w-3.5 h-3.5 text-[#67c1f5]" />
            <span>Inspect Proof</span>
          </button>
        </div>

        {/* Steamworks Header */}
        <div className="mb-4">
          <h4 className="text-base sm:text-lg font-medium text-white tracking-wide">
            Wishlist Actions - {data.gameName} ({data.appId})
          </h4>
          <p className="text-xs text-[#67c1f5] hover:underline cursor-pointer">
            &lt;&lt; back to {data.gameName}
          </p>

          {/* Color ticker bar matching Steamworks UI */}
          <div className="h-1.5 w-full mt-3 flex rounded-full overflow-hidden opacity-90">
            <span className="w-1/6 bg-[#3888d8]"></span>
            <span className="w-1/6 bg-[#4c90d8]"></span>
            <span className="w-1/6 bg-[#68c654]"></span>
            <span className="w-1/6 bg-[#d1b038]"></span>
            <span className="w-1/6 bg-[#d18438]"></span>
            <span className="w-1/6 bg-[#cf3c3c]"></span>
          </div>
        </div>

        {/* Lifetime Overview Block */}
        <div className="bg-[#10151c] rounded border border-[#212b36] p-4">
          <div className="text-sm font-semibold text-white tracking-wide mb-3 border-b border-[#212b36] pb-2">
            Lifetime Overview
          </div>

          <div className="space-y-2.5 text-xs sm:text-sm font-mono">
            <div className="flex justify-between items-center py-1 border-b border-[#1b242e]">
              <span className="text-[#8f98a0]">Wishlist Additions</span>
              <span className="text-white font-bold text-sm sm:text-base tracking-wider">{data.wishlistAdditions}</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-[#1b242e]">
              <span className="text-[#8f98a0]">Wishlist Deletions</span>
              <span className="text-[#8f98a0]">{data.wishlistDeletions}</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-[#1b242e]">
              <span className="text-[#8f98a0]">Wishlist Purchases &amp; Activations</span>
              <span className="text-[#8f98a0]">{data.purchasesActivations}</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-[#1b242e]">
              <span className="text-[#8f98a0]">Wishlist Gifts</span>
              <span className="text-[#8f98a0]">{data.wishlistGifts}</span>
            </div>
            <div className="flex justify-between items-center pt-2 pb-1 bg-[#1b2633] px-3 -mx-3 rounded border-l-2 border-[#5cff67]">
              <span className="text-white font-semibold">Current Outstanding Wishes</span>
              <span className="text-[#5cff67] font-bold text-base sm:text-lg tracking-wider">
                {data.currentOutstandingWishes}
              </span>
            </div>
            <div className="flex justify-between items-center py-1 text-xs text-[#8f98a0]">
              <span>Lifetime Conversion Rate</span>
              <span className="text-white">{data.lifetimeConversionRate}</span>
            </div>
            <div className="text-[11px] text-[#55677d] italic leading-tight">
              - {data.conversionNote}
            </div>
            <div className="flex justify-between items-center pt-2 text-xs border-t border-[#1b242e]">
              <span className="text-[#8f98a0]">Date First Wishlisted</span>
              <span className="text-white font-mono">{data.dateFirstWishlisted}</span>
            </div>
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between text-[11px] text-[#627588]">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-[#5cff67]" /> Verified Direct Steam Partner Export
          </span>
          <span className="text-[#a4b8cc] font-mono font-medium">{data.retentionRate}</span>
        </div>
      </div>
    );
  }

  if (type === 'traffic_analytics') {
    const isNecrosis = id === 'proof-cuttly-necrosis';
    return (
      <div
        id={id}
        onClick={handleInspect}
        className={`group relative bg-[#0f1117] border border-[#222736] rounded-lg p-4 sm:p-5 transition-all hover:border-[#38435f] cursor-pointer shadow-xl ${className}`}
      >
        {/* Top bar */}
        <div className="flex items-center justify-between border-b border-[#1c2130] pb-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-[#1e2334] text-[#8ea5cc] border border-[#2b334a]">
              VERIFIED LINK TRACKER &amp; REFERRER
            </span>
            <span className="text-xs text-[#6e7d9b] hidden sm:inline">{date}</span>
          </div>
          <button
            type="button"
            className="flex items-center gap-1.5 text-xs text-[#8ea5cc] group-hover:text-white px-2 py-1 rounded bg-[#161a27] border border-[#283147] transition-colors"
          >
            <ZoomIn className="w-3.5 h-3.5 text-[#4e95ff]" />
            <span>Inspect</span>
          </button>
        </div>

        {isNecrosis && (
          <div className="mb-4 bg-[#141824] rounded border border-[#232a3d] p-3">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-5 h-5 rounded-full bg-[#1b2838] flex items-center justify-center text-[10px] text-[#67c1f5] font-bold">
                    S
                  </div>
                  <h4 className="text-sm font-semibold text-white truncate">
                    Necrosis: Dawn of Dread on Steam
                  </h4>
                </div>
                <div className="text-[11px] font-mono text-[#6c7d9d] truncate">
                  https://store.steampowered.com/app/3155010/Necrosis_Dawn_of_Dread/
                </div>
                <div className="text-xs font-mono text-[#4e95ff] mt-1 flex items-center gap-1">
                  <span>https://cutt.ly/er55yLB7</span>
                  <ArrowUpRight className="w-3 h-3" />
                </div>
              </div>

              <div className="flex flex-col items-end shrink-0">
                <div className="flex items-center rounded overflow-hidden border border-[#2b569a]">
                  <span className="bg-[#16253c] text-[#8cb4e8] px-2 py-1 text-xs">Total clicks</span>
                  <span className="bg-[#1f6feb] text-white font-bold px-2.5 py-1 text-xs font-mono">
                    3990
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {!isNecrosis && (
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="text-sm sm:text-base font-semibold text-white">{title}</h4>
              <p className="text-xs text-[#7d8ea9]">{subtitle}</p>
            </div>
            <div className="flex items-center rounded overflow-hidden border border-[#2b569a]">
              <span className="bg-[#16253c] text-[#8cb4e8] px-2 py-1 text-xs">Total clicks</span>
              <span className="bg-[#1f6feb] text-white font-bold px-3 py-1 text-sm font-mono">
                {data.totalClicks}
              </span>
            </div>
          </div>
        )}

        {/* SVG Graph rendering of the curve */}
        <div className="bg-[#0b0d13] rounded border border-[#1b202e] p-3 relative">
          <div className="flex justify-between items-center text-[11px] text-[#606f8c] font-mono mb-2">
            <span>Surge Peak: {data.peakDailyClicks || '2,176/day'}</span>
            <span className="bg-[#161a25] px-2 py-0.5 rounded text-[#7e8fad]">Status: Private stats</span>
          </div>

          <div className="h-32 sm:h-36 w-full relative flex items-end">
            {/* SVG Wave */}
            <svg viewBox="0 0 400 130" className="w-full h-full overflow-visible" preserveAspectRatio="none">
              <defs>
                <linearGradient id={`grad-${id}`} x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#388bfd" stopOpacity="0.45" />
                  <stop offset="100%" stopColor="#388bfd" stopOpacity="0.02" />
                </linearGradient>
              </defs>

              {/* Grid lines */}
              <line x1="0" y1="20" x2="400" y2="20" stroke="#1d2333" strokeDasharray="3 3" />
              <line x1="0" y1="60" x2="400" y2="60" stroke="#1d2333" strokeDasharray="3 3" />
              <line x1="0" y1="100" x2="400" y2="100" stroke="#1d2333" strokeDasharray="3 3" />

              {/* Path */}
              {isNecrosis ? (
                <>
                  <path
                    d="M 0,120 Q 80,110 140,75 T 200,15 T 260,65 T 400,95 L 400,130 L 0,130 Z"
                    fill={`url(#grad-${id})`}
                  />
                  <path
                    d="M 0,120 Q 80,110 140,75 T 200,15 T 260,65 T 400,95"
                    fill="none"
                    stroke="#388bfd"
                    strokeWidth="2.5"
                  />
                  <circle cx="200" cy="15" r="4" fill="#58a6ff" />
                </>
              ) : id === 'proof-traffic-surge-10540' ? (
                <>
                  <path
                    d="M 0,125 L 80,125 Q 120,105 160,80 T 240,40 T 320,10 T 400,90 L 400,130 L 0,130 Z"
                    fill={`url(#grad-${id})`}
                  />
                  <path
                    d="M 0,125 L 80,125 Q 120,105 160,80 T 240,40 T 320,10 T 400,90"
                    fill="none"
                    stroke="#388bfd"
                    strokeWidth="2.5"
                  />
                  <circle cx="320" cy="10" r="4" fill="#58a6ff" />
                </>
              ) : (
                <>
                  <path
                    d="M 0,125 L 75,125 Q 115,85 150,75 T 230,45 T 290,18 T 400,70 L 400,130 L 0,130 Z"
                    fill={`url(#grad-${id})`}
                  />
                  <path
                    d="M 0,125 L 75,125 Q 115,85 150,75 T 230,45 T 290,18 T 400,70"
                    fill="none"
                    stroke="#388bfd"
                    strokeWidth="2.5"
                  />
                  <circle cx="290" cy="18" r="4" fill="#58a6ff" />
                </>
              )}
            </svg>
          </div>

          <div className="flex justify-between items-center text-[10px] text-[#556480] font-mono mt-2 pt-2 border-t border-[#181d2a]">
            <span>Start: Baseline</span>
            <span className="text-[#8ba2c7]">Peak Surge: {data.peakDailyClicks || '2,176 clicks'}</span>
            <span>Target: Steam Acquisition</span>
          </div>
        </div>
      </div>
    );
  }

  if (type === 'campaign_crm') {
    return (
      <div
        id={id}
        onClick={handleInspect}
        className={`group relative bg-[#101217] border border-[#232733] rounded-lg p-4 sm:p-5 transition-all hover:border-[#3d4559] cursor-pointer shadow-xl ${className}`}
      >
        <div className="flex items-center justify-between border-b border-[#1c202b] pb-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-[#1e2430] text-[#93a7c6] border border-[#2c3447]">
              CAMPAIGN DISTRIBUTION ENGINE
            </span>
            <span className="text-xs text-[#62718a] hidden sm:inline">{sourceLabel}</span>
          </div>
          <button
            type="button"
            className="flex items-center gap-1.5 text-xs text-[#8ea5cc] group-hover:text-white px-2 py-1 rounded bg-[#151924] border border-[#262f42] transition-colors"
          >
            <ZoomIn className="w-3.5 h-3.5 text-[#58a6ff]" />
            <span>Inspect</span>
          </button>
        </div>

        {/* Dashboard table mockup matching exact uploaded screenshot */}
        <div className="bg-[#161a22] border border-[#262c3b] rounded overflow-x-auto">
          <div className="px-3 py-2 border-b border-[#262c3b] bg-[#12151c] flex items-center justify-between text-xs text-[#7e8ea6]">
            <span className="font-semibold text-white">Campaigns Overview</span>
            <span className="text-[11px] font-mono">Date range: Last 30 days</span>
          </div>

          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#232837] text-[#6d7c95] text-[11px]">
                <th className="py-2.5 px-3 font-medium">Campaign</th>
                <th className="py-2.5 px-2 font-medium">Status</th>
                <th className="py-2.5 px-3 font-medium">Send date</th>
                <th className="py-2.5 px-3 font-medium text-right">Open rate</th>
                <th className="py-2.5 px-3 font-medium text-right">Click rate</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-[#1f2431] text-white">
                <td className="py-3 px-3">
                  <div className="font-sans font-semibold text-white text-xs sm:text-sm flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-[#859ab8]" />
                    <span>{data.campaignName}</span>
                  </div>
                  <div className="text-[11px] text-[#6d7d96] font-mono mt-0.5">Direct Audience Outreach</div>
                </td>
                <td className="py-3 px-2">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#143d24] text-[#46ec7b] border border-[#1f5c36]">
                    Sent
                  </span>
                </td>
                <td className="py-3 px-3 text-[#8ca0be] text-[11px] whitespace-nowrap">
                  {data.sendDate}
                </td>
                <td className="py-3 px-3 text-right">
                  <div className="text-sm font-bold text-[#5cff87]">{data.openRate}</div>
                  <div className="text-[10px] text-[#6d7e98]">{data.recipients} recipients</div>
                </td>
                <td className="py-3 px-3 text-right">
                  <div className="text-sm font-bold text-[#58a6ff]">{data.clickRate}</div>
                  <div className="text-[10px] text-[#6d7e98]">{data.clickedRecipients}</div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mt-3 flex items-center justify-between text-xs text-[#70809b]">
          <span>Verified conversion action recorded</span>
          <span className="font-semibold text-white font-mono">{evidence.metricHighlight}</span>
        </div>
      </div>
    );
  }

  return null;
};
