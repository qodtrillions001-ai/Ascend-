import React from 'react';
import { Project } from '../types';
import { ProjectImage } from './ProjectImage';
import { ArrowUpRight } from 'lucide-react';

interface MoreWorkProps {
  projects: Project[];
  onSelectProject: (project: Project) => void;
}

export const MoreWork: React.FC<MoreWorkProps> = ({ projects, onSelectProject }) => {
  return (
    <section id="more-work" className="py-20 sm:py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#1a1d29]">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
        <div>
          <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block mb-2">
            ARCHIVE &amp; EXPERIMENTS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display">
            ALL CAMPAIGN RECORDS
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-[#7f8fa5] font-mono">
          Click any project to inspect the documented campaign dossier
        </p>
      </div>

      {/* Grid gallery */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <div
            key={project.id}
            id={`more-work-${project.id}`}
            onClick={() => onSelectProject(project)}
            className="group relative bg-[#0e1017] rounded-xl border border-[#1f2434] hover:border-[#3b4766] transition-all duration-300 overflow-hidden cursor-pointer flex flex-col justify-between"
          >
            {/* Image Preview */}
            <div className="relative h-48 w-full overflow-hidden bg-[#0a0c10]">
              <ProjectImage
                src={project.heroImage}
                fallbackSrc={project.fallbackImage}
                alt={project.title}
                genre={project.genre}
                className="group-hover:scale-103 transition-transform duration-500 opacity-85"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0e1017] via-transparent to-transparent pointer-events-none" />

              <div className="absolute top-3 left-3 pointer-events-none">
                <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-black/70 backdrop-blur text-[#c5a059] border border-white/10">
                  {project.genre}
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="p-5 flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <h3 className="text-lg font-bold text-white font-display group-hover:text-[#e4be78] transition-colors">
                    {project.title}
                  </h3>
                  <ArrowUpRight className="w-4 h-4 text-[#72839d] group-hover:text-white transition-colors" />
                </div>
                <p className="text-xs text-[#8e9eb5] line-clamp-2 leading-relaxed mb-4">
                  {project.overview}
                </p>
              </div>

              {/* Documented Outcome Tag */}
              <div className="pt-3 border-t border-[#181d29] flex items-center justify-between text-xs font-mono">
                <span className="text-[#657791]">Key Result</span>
                <span className="text-white font-bold">{project.primaryResult}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
