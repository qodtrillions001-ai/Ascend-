import React, { useState } from 'react';
import { PROOF_EVIDENCE_ITEMS, CLIENT_REVIEWS } from '../data/portfolioData';
import { ProofEvidence, ClientReview } from '../types';
import { ProofVisualCard } from './ProofVisualCard';
import { ShieldCheck, Star, ZoomIn, CheckCircle2, ChevronRight, ChevronLeft } from 'lucide-react';

interface ProofCredibilityProps {
  onInspectProof: (evidence: ProofEvidence) => void;
}

export const ProofCredibility: React.FC<ProofCredibilityProps> = ({ onInspectProof }) => {
  const [activeTab, setActiveTab] = useState<'all' | 'steam' | 'traffic' | 'campaigns'>('all');

  const filteredProofs = PROOF_EVIDENCE_ITEMS.filter((item) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'steam') return item.type === 'steamworks';
    if (activeTab === 'traffic') return item.type === 'traffic_analytics';
    if (activeTab === 'campaigns') return item.type === 'campaign_crm';
    return true;
  });

  return (
    <section id="proof" className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#1a1d29]">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
        <div>
          <span className="text-xs font-mono text-[#5cff87] uppercase tracking-widest flex items-center gap-1.5 mb-2">
            <ShieldCheck className="w-4 h-4" /> VERIFIED EVIDENCE
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display">
            THE WORK SPEAKS FOR ITSELF.
          </h2>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-2 font-mono text-xs overflow-x-auto pb-1">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'all'
                ? 'bg-[#5c1424] text-white'
                : 'bg-[#12141d] text-[#8696ad] hover:text-white border border-[#202535]'
            }`}
          >
            All Evidence
          </button>
          <button
            onClick={() => setActiveTab('steam')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'steam'
                ? 'bg-[#5c1424] text-white'
                : 'bg-[#12141d] text-[#8696ad] hover:text-white border border-[#202535]'
            }`}
          >
            Steamworks
          </button>
          <button
            onClick={() => setActiveTab('traffic')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'traffic'
                ? 'bg-[#5c1424] text-white'
                : 'bg-[#12141d] text-[#8696ad] hover:text-white border border-[#202535]'
            }`}
          >
            Traffic Analytics
          </button>
          <button
            onClick={() => setActiveTab('campaigns')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'campaigns'
                ? 'bg-[#5c1424] text-white'
                : 'bg-[#12141d] text-[#8696ad] hover:text-white border border-[#202535]'
            }`}
          >
            Direct Outreach
          </button>
        </div>
      </div>

      {/* Proof Gallery Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-16">
        {filteredProofs.map((evidence) => (
          <ProofVisualCard
            key={evidence.id}
            evidence={evidence}
            onInspect={onInspectProof}
          />
        ))}
      </div>

      {/* Verified Developer Reviews Section (Source of truth: uploaded receipts) */}
      <div className="pt-10 border-t border-[#1a1e2d]">
        <div className="mb-8 flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <div>
            <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block mb-1">
              DIRECT CLIENT FEEDBACK
            </span>
            <h3 className="text-2xl sm:text-3xl font-bold text-white font-display">
              Documented Client Reviews
            </h3>
          </div>
          <span className="text-xs font-mono text-[#6c7d96]">
            Unedited reviews transcribed directly from campaign delivery receipts
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {CLIENT_REVIEWS.map((review, i) => (
            <div
              key={i}
              id={`review-card-${review.username}`}
              className="p-6 rounded-xl bg-[#0d0f16] border border-[#1e2334] flex flex-col justify-between"
            >
              <div>
                {/* Header with Username & Stars */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-full ${review.avatarColor} text-white font-bold text-xs flex items-center justify-center`}
                    >
                      {review.avatarLetter}
                    </div>
                    <div>
                      <span className="text-sm font-semibold text-white block">
                        {review.username}'s message
                      </span>
                      <div className="flex items-center text-[#ffb800] text-xs mt-0.5">
                        {[...Array(review.rating)].map((_, idx) => (
                          <Star key={idx} className="w-3.5 h-3.5 fill-current" />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Review body */}
                <p className="text-xs sm:text-sm text-[#b2c0d5] leading-relaxed italic mb-5">
                  "{review.message}"
                </p>
              </div>

              {/* Verified Metrics / Criteria Breakdown if provided */}
              <div className="pt-4 border-t border-[#181d2a] space-y-2">
                {review.ratings && (
                  <div className="space-y-1.5 text-[11px] font-mono text-[#7888a2]">
                    <div className="flex justify-between items-center">
                      <span>Seller communication</span>
                      <span className="text-[#ffb800] flex items-center gap-1">
                        ★★★★★ 5
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Quality of delivery</span>
                      <span className="text-[#ffb800] flex items-center gap-1">
                        ★★★★★ 5
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Value of delivery</span>
                      <span className="text-[#ffb800] flex items-center gap-1">
                        ★★★★★ 5
                      </span>
                    </div>
                  </div>
                )}

                {review.highlights && (
                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {review.highlights.map((hl, hIdx) => (
                      <span
                        key={hIdx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#151924] text-[#869ab8] border border-[#232a3d]"
                      >
                        {hl}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
