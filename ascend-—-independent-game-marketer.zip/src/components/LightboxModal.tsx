import React, { useEffect } from 'react';
import { ProofEvidence } from '../types';
import { X, ShieldCheck, ExternalLink, ZoomIn, CheckCircle2, ChevronRight } from 'lucide-react';

interface LightboxModalProps {
  evidence: ProofEvidence | null;
  imageSrc?: string | null;
  imageTitle?: string;
  onClose: () => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  evidence,
  imageSrc,
  imageTitle,
  onClose
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (evidence || imageSrc) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [evidence, imageSrc, onClose]);

  if (!evidence && !imageSrc) return null;

  return (
    <div
      id="lightbox-overlay"
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div
        id="lightbox-dialog"
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-[#0e1015] border border-[#262b3a] rounded-xl shadow-2xl p-4 sm:p-6 text-[#e2e4ec]"
      >
        {/* Top Header */}
        <div className="flex items-start justify-between border-b border-[#202533] pb-4 mb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#c5a059] mb-1">
              <ShieldCheck className="w-4 h-4 text-[#5cff87]" />
              <span className="uppercase tracking-wider">VERIFIED CAMPAIGN EVIDENCE</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {evidence ? evidence.title : imageTitle || 'Asset Preview'}
            </h3>
            {evidence && (
              <p className="text-xs sm:text-sm text-[#7f8da4] mt-0.5">{evidence.subtitle}</p>
            )}
          </div>

          <button
            id="lightbox-close-btn"
            onClick={onClose}
            type="button"
            className="p-2 rounded-lg bg-[#161a24] text-[#8e9cb3] hover:text-white hover:bg-[#202636] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        {imageSrc ? (
          <div className="space-y-4">
            <div className="relative rounded-lg overflow-hidden border border-[#222736] bg-[#08090c] max-h-[65vh] flex items-center justify-center">
              <img
                src={imageSrc}
                alt={imageTitle || 'Campaign Evidence'}
                className="w-full h-auto max-h-[65vh] object-contain"
              />
            </div>
            <div className="text-xs text-[#70809b] flex items-center justify-between font-mono">
              <span>Full resolution display</span>
              <span>Direct visual capture</span>
            </div>
          </div>
        ) : evidence ? (
          <div className="space-y-6">
            {/* Primary Highlight Banner */}
            {evidence.metricHighlight && (
              <div className="p-4 rounded-lg bg-[#141824] border border-[#283248] flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-mono text-[#8ca0be] uppercase tracking-wider">
                    KEY VERIFIED OUTCOME
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono mt-0.5">
                    {evidence.metricHighlight}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-[#6e7d95]">Recorded Date</div>
                  <div className="text-xs font-mono text-[#c5a059] font-medium">{evidence.date}</div>
                </div>
              </div>
            )}

            {/* Evidence Data Details */}
            <div className="bg-[#0b0d12] rounded-lg border border-[#1d222e] p-4 sm:p-5">
              <h4 className="text-xs uppercase font-mono tracking-wider text-[#8b9bb2] mb-3 border-b border-[#1b202c] pb-2">
                Documented Field Evidence &amp; Telemetry
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm font-mono">
                {Object.entries(evidence.data).map(([key, val]) => (
                  <div
                    key={key}
                    className="p-2.5 rounded bg-[#12151d] border border-[#1e2330] flex flex-col justify-between"
                  >
                    <span className="text-[11px] text-[#6b7b93] capitalize">
                      {key.replace(/([A-Z])/g, ' $1')}
                    </span>
                    <span className="text-white font-semibold text-sm mt-1 break-all">
                      {String(val)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-[#1c212d] text-xs text-[#67778f]">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#5cff87]" />
                Strict Non-Fabrication Guarantee: Data directly transcribed from uploaded proof
              </span>
              <button
                onClick={onClose}
                type="button"
                className="px-4 py-2 rounded bg-[#1c212e] text-white hover:bg-[#252c3d] font-medium transition-colors"
              >
                Close View
              </button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
