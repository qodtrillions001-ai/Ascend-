import { Project, ProofEvidence, ClientReview } from '../types';
import { GAME_IMAGES } from './projectImages';

export const PROOF_EVIDENCE_ITEMS: ProofEvidence[] = [
  {
    id: 'proof-steamworks-gamewithballs',
    type: 'steamworks',
    title: 'Wishlist Actions — Game With Balls (3745250)',
    subtitle: 'Steamworks Lifetime Wishlist Report',
    sourceLabel: 'Steamworks Official Partner Analytics',
    date: 'Lifetime (First Wishlisted: 2025-06-09)',
    metricHighlight: '10,005 Outstanding Wishes',
    data: {
      gameName: 'Game With Balls',
      appId: '3745250',
      wishlistAdditions: '10,843',
      wishlistDeletions: '(837)',
      purchasesActivations: '(1)',
      wishlistGifts: '0',
      currentOutstandingWishes: '10,005',
      lifetimeConversionRate: '0.0%',
      conversionNote: 'Insufficient data points to be compared against others on Steam (?)',
      dateFirstWishlisted: '2025-06-09',
      retentionRate: '92.3% active wishlist retention'
    }
  },
  {
    id: 'proof-cuttly-necrosis',
    type: 'traffic_analytics',
    title: 'Necrosis: Dawn of Dread on Steam',
    subtitle: 'Tracked Direct Store Traffic (cutt.ly/er55yLB7)',
    sourceLabel: 'Verified Link Tracker & Referrer Analytics',
    date: '30-Day Campaign Window',
    metricHighlight: '3,990 Verified Clicks',
    data: {
      gameName: 'Necrosis: Dawn of Dread',
      storeUrl: 'https://store.steampowered.com/app/3155010/Necrosis_Dawn_of_Dread/',
      shortLink: 'https://cutt.ly/er55yLB7',
      totalClicks: '3,990',
      peakDailyClicks: '2,176 clicks/day',
      surgeShape: 'Concentrated launch week spike',
      status: 'Private stats'
    }
  },
  {
    id: 'proof-crm-lirai',
    type: 'campaign_crm',
    title: 'Lirai Heir Of Darkness Leads',
    subtitle: 'Direct Audience Email & Community Distribution',
    sourceLabel: 'Direct Campaign Distribution System',
    date: 'Jan 20, 2026, 11:12 AM GMT+2',
    metricHighlight: '87.72% Open Rate · 8,000 Clicks',
    data: {
      campaignName: 'Lirai Heir Of Darkness Leads',
      status: 'Sent',
      sendDate: 'Jan 20, 2026, 11:12 AM GMT+2',
      recipients: '20,000',
      openRate: '87.72%',
      clickRate: '40%',
      clickedRecipients: '8,000 recipients',
      activeOnSite: '5% (1,000)'
    }
  },
  {
    id: 'proof-crm-artifactory',
    type: 'campaign_crm',
    title: 'The Artifactory Leads',
    subtitle: 'Targeted Gaming Audience Dispatch',
    sourceLabel: 'Direct Campaign Distribution System',
    date: 'Jan 23, 2026, 10:50 AM GMT+2',
    metricHighlight: '80.4% Open Rate · 69.8% Click Rate',
    data: {
      campaignName: 'The Artifactory Leads',
      status: 'Sent',
      sendDate: 'Jan 23, 2026, 10:50 AM GMT+2',
      recipients: '8,042',
      openRate: '80.4%',
      clickRate: '69.8%',
      clickedRecipients: '6,983 recipients'
    }
  },
  {
    id: 'proof-traffic-surge-10540',
    type: 'traffic_analytics',
    title: 'Launch Traffic Surge (Wave II)',
    subtitle: 'Multi-Channel Acquisition Tracking',
    sourceLabel: 'Verified Link Tracker & Referrer Analytics',
    date: 'Jan 13 – Jan 24, 2026',
    metricHighlight: '10,540 Total Clicks',
    data: {
      totalClicks: '10,540',
      peakDailyClicks: '2,275 clicks/day (Jan 23)',
      range: 'Jan 13 – Jan 24, 2026',
      status: 'Private stats'
    }
  },
  {
    id: 'proof-traffic-surge-8541',
    type: 'traffic_analytics',
    title: 'Pre-Launch Velocity (Wave I)',
    subtitle: 'Niche Community Referral Run',
    sourceLabel: 'Verified Link Tracker & Referrer Analytics',
    date: 'Jan 13 – Jan 23, 2026',
    metricHighlight: '8,541 Total Clicks',
    data: {
      totalClicks: '8,541',
      peakDailyClicks: '1,949 clicks/day (Jan 21)',
      range: 'Jan 13 – Jan 23, 2026',
      status: 'Private stats'
    }
  }
];

export const CLIENT_REVIEWS: ClientReview[] = [
  {
    username: 'kareelhicks',
    avatarLetter: 'K',
    avatarColor: 'bg-[#4a2e58]',
    rating: 5,
    message:
      'I had an excellent time collaborating on the campaign. The results that I received far exceeded my expectations and I will utilize these services again very soon! Thank you for your incredible work, proactive communication, and your teamwork!',
    highlights: ['Proactive communication', 'Teamwork', 'Exceeded expectations']
  },
  {
    username: 'tdurdenart',
    avatarLetter: 'T',
    avatarColor: 'bg-[#1e3a4c]',
    rating: 5,
    message: 'Honest and accountable. All I could ask for.',
    ratings: {
      communication: 5,
      quality: 5,
      value: 5
    },
    highlights: ['Honest and accountable', 'High delivery quality']
  },
  {
    username: 'xazrael',
    avatarLetter: 'X',
    avatarColor: 'bg-[#b91c1c]',
    rating: 5,
    message:
      "So, here's my feedback. I got 2.3k impressions, but it didn't really bring much. I still don't fully understand how this system works. It seems that to make this kind of marketing worthwhile, you need a properly prepared page — a trailer, gameplay footage, solid screenshots. I did get the traffic that was promised, and the rest depends on the developers themselves.",
    ratings: {
      communication: 5,
      quality: 5,
      value: 5
    },
    highlights: ['Politeness', 'Delivery time', 'Quick responsiveness', 'Delivered promised traffic']
  }
];

export const PROJECTS: Project[] = [
  {
    id: 'game-with-balls',
    title: 'Game With Balls',
    appId: '3745250',
    genre: 'Physics Arcade / Indie',
    tagline: 'Cross-platform audience acquisition pushing past 10,000 outstanding Steam wishlists.',
    heroImage: GAME_IMAGES.gameWithBalls,
    fallbackImage: GAME_IMAGES.gameWithBalls,
    campaignType: 'Steam Wishlist Scaling & Targeted Community Funnel',
    primaryResult: '10,005 Outstanding Wishes',
    secondaryResult: '10,843 Total Additions (92.3% retention)',
    overview:
      'Targeted campaign driving focused player attention into confirmed Steam wishlists prior to commercial launch, maintaining a low deletion rate under 8%.',
    approach:
      'Identified players engaging with physics-driven and emergent gameplay. Directed concentrated traffic waves toward the Steam store page during peak activity windows.',
    execution:
      'Coordinated distribution across gaming communities and targeted outreach, driving sustained additions recorded directly in Steamworks partner reporting.',
    resultsSummary:
      '10,843 total wishlist additions resulting in 10,005 current outstanding wishes, with only 837 deletions recorded over the lifetime period.',
    metrics: [
      { label: 'OUTSTANDING WISHES', value: '10,005', verifiedSource: 'Steamworks Lifetime Overview' },
      { label: 'WISHLIST ADDITIONS', value: '10,843', verifiedSource: 'Steamworks Partner Dashboard' },
      { label: 'RETENTION RATE', value: '92.3%', verifiedSource: '837 deletions vs 10.8k additions' },
      { label: 'TRACKED APP ID', value: '3745250', verifiedSource: 'Official Steam Application ID' }
    ],
    proofId: 'proof-steamworks-gamewithballs'
  },
  {
    id: 'necrosis-dawn-of-dread',
    title: 'Necrosis: Dawn of Dread',
    appId: '3155010',
    genre: 'Atmospheric Survival Horror',
    tagline: 'Targeted Steam store link routing driving a 2,100+ single-day click surge.',
    heroImage: GAME_IMAGES.necrosis,
    fallbackImage: GAME_IMAGES.necrosis,
    campaignType: 'Store Link Tracking & Targeted Traffic Routing',
    primaryResult: '3,990 Verified Clicks',
    secondaryResult: '2,176 Peak Single-Day Surge',
    overview:
      'Direct-to-store promotion targeting psychological and survival horror fans on Steam, using tagged link routing to measure player acquisition intent.',
    approach:
      'Built focused promotional distribution through dedicated horror gaming community channels and direct player discovery touchpoints.',
    execution:
      'Routed incoming traffic through verified tracking link (cutt.ly/er55yLB7) directly to Steam store page 3155010 to monitor real-time traffic spikes.',
    resultsSummary:
      'Generated 3,990 verified unique clicks within the 30-day monitoring window, peaking with an intensive 2,176 single-day player discovery surge.',
    metrics: [
      { label: 'VERIFIED CLICKS', value: '3,990', verifiedSource: 'cutt.ly Link Analytics' },
      { label: 'PEAK SINGLE-DAY', value: '2,176', verifiedSource: 'Day-over-day surge curve' },
      { label: 'DESTINATION', value: 'Steam Store', verifiedSource: 'store.steampowered.com/app/3155010' }
    ],
    proofId: 'proof-cuttly-necrosis',
    steamUrl: 'https://store.steampowered.com/app/3155010/Necrosis_Dawn_of_Dread/'
  },
  {
    id: 'lirai-heir-of-darkness',
    title: 'Lirai: Heir of Darkness',
    genre: 'Dark Fantasy Action RPG',
    tagline: 'High-intent community campaign delivering an 87.7% open rate and 8,000 click-throughs.',
    heroImage: GAME_IMAGES.lirai,
    fallbackImage: GAME_IMAGES.lirai,
    campaignType: 'Direct Player Outreach & Targeted Subscriber Distribution',
    primaryResult: '87.72% Open Rate',
    secondaryResult: '8,000 Clicked Recipients (40% CTR)',
    overview:
      'A segmented outreach campaign reaching 20,000 qualified dark fantasy and action RPG players with direct promotional dispatches.',
    approach:
      'Filtered audience targeting to match dark fantasy aesthetic preferences and demonstrated indie RPG purchase history.',
    execution:
      'Executed unified broadcast on Jan 20, 2026. Monitored delivery, open rates, and click actions in real time.',
    resultsSummary:
      '20,000 recipients reached, yielding an 87.72% open rate and 40% click rate (8,000 direct recipients clicking through to game channels).',
    metrics: [
      { label: 'OPEN RATE', value: '87.72%', verifiedSource: 'Campaign Dispatch Metrics' },
      { label: 'CLICK-THROUGHS', value: '8,000', verifiedSource: '40.0% CTR on 20k recipients' },
      { label: 'AUDIENCE SIZE', value: '20,000', verifiedSource: 'Jan 20, 2026 Campaign Report' }
    ],
    proofId: 'proof-crm-lirai'
  },
  {
    id: 'the-artifactory',
    title: 'The Artifactory',
    genre: 'Steampunk Crafting & Adventure',
    tagline: 'Niche audience activation recording an exceptional 69.8% direct click-through rate.',
    heroImage: GAME_IMAGES.artifactory,
    fallbackImage: GAME_IMAGES.artifactory,
    campaignType: 'Targeted Subscriber Activation & Niche Funnel',
    primaryResult: '69.8% Click Rate',
    secondaryResult: '6,983 Direct Actions from 8,042 Recipients',
    overview:
      'Hyper-focused audience campaign for an inventive steampunk crafting title, proving that precision targeting drives exceptional engagement.',
    approach:
      'Isolated players passionate about deep crafting systems, industrial aesthetics, and indie puzzle mechanics rather than broad generic blasts.',
    execution:
      'Dispatched campaign on Jan 23, 2026 to 8,042 verified recipients with tailored creative copy and immediate action links.',
    resultsSummary:
      'Achieved an 80.4% open rate and a 69.8% click rate, translating to 6,983 distinct player actions from 8,042 total recipients.',
    metrics: [
      { label: 'CLICK RATE', value: '69.8%', verifiedSource: 'Campaign Dispatch Analytics' },
      { label: 'OPEN RATE', value: '80.4%', verifiedSource: '8,042 Verified Recipients' },
      { label: 'DIRECT ACTIONS', value: '6,983', verifiedSource: 'Verified Click Count' }
    ],
    proofId: 'proof-crm-artifactory'
  },
  {
    id: 'launch-traffic-surges',
    title: 'Multi-Wave Player Acquisition',
    genre: 'Multi-Title Promotional Run',
    tagline: 'Documented traffic surges generating over 19,000 verified player visits across twin campaign waves.',
    heroImage: GAME_IMAGES.necrosis,
    fallbackImage: GAME_IMAGES.necrosis,
    campaignType: 'Multi-Wave Traffic Acceleration',
    primaryResult: '19,081 Combined Clicks',
    secondaryResult: '2,275 Peak Day Clicks',
    overview:
      'Coordinated multi-channel promotion across Reddit communities, targeted social segments, and creator placements during January 2026.',
    approach:
      'Structured distribution in consecutive waves to test hook resonance and build momentum into key platform visibility milestones.',
    execution:
      'Monitored incoming referral volume across dual tracking streams (10,540 clicks and 8,541 clicks) with real-time day-by-day telemetry.',
    resultsSummary:
      'Wave 1 delivered 8,541 clicks peaking at 1,949 on Jan 21; Wave 2 pushed 10,540 clicks peaking at 2,275 on Jan 23.',
    metrics: [
      { label: 'WAVE II CLICKS', value: '10,540', verifiedSource: 'Cutt.ly Traffic Telemetry' },
      { label: 'WAVE I CLICKS', value: '8,541', verifiedSource: 'Cutt.ly Traffic Telemetry' },
      { label: 'COMBINED CLICKS', value: '19,081', verifiedSource: 'Total Documented Traffic' }
    ],
    proofId: 'proof-traffic-surge-10540',
    additionalProofIds: ['proof-traffic-surge-8541']
  }
];

export const SERVICES = [
  {
    title: 'Game Promotion',
    description: 'Steam traffic, wishlists and player acquisition.',
    tag: 'CORE'
  },
  {
    title: 'Targeted Outreach',
    description: 'Direct promotion toward relevant gaming audiences.',
    tag: 'TARGETING'
  },
  {
    title: 'Gaming Communities',
    description: 'Distribution through relevant communities and niche audiences.',
    tag: 'COMMUNITY'
  },
  {
    title: 'Reddit Marketing',
    description: 'Organic community-focused promotion.',
    tag: 'ORGANIC'
  },
  {
    title: 'Creator Outreach',
    description: 'Connecting games with relevant creators and gaming personalities.',
    tag: 'INFLUENCE'
  },
  {
    title: 'Meta Ads',
    description: 'Paid campaigns targeting relevant player segments.',
    tag: 'PAID'
  }
];

export const APPROACH_STAGES = [
  {
    step: '01',
    title: 'FIND',
    description: 'Identify the audience already interested in similar games.'
  },
  {
    step: '02',
    title: 'DISTRIBUTE',
    description: 'Put the game in front of relevant players through targeted channels.'
  },
  {
    step: '03',
    title: 'MOVE',
    description: 'Turn attention into traffic, wishlists, players, creators or sales.'
  }
];
