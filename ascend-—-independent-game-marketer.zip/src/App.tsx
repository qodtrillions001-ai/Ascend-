/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PROJECTS, PROOF_EVIDENCE_ITEMS } from './data/portfolioData';
import { Project, ProofEvidence } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SelectedWork } from './components/SelectedWork';
import { FeaturedCaseStudy } from './components/FeaturedCaseStudy';
import { MoreWork } from './components/MoreWork';
import { WhatIDo } from './components/WhatIDo';
import { TheApproach } from './components/TheApproach';
import { ProofCredibility } from './components/ProofCredibility';
import { AboutSection } from './components/AboutSection';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { CaseStudyModal } from './components/CaseStudyModal';
import { LightboxModal } from './components/LightboxModal';
import { ContactModal } from './components/ContactModal';

export default function App() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [inspectEvidence, setInspectEvidence] = useState<ProofEvidence | null>(null);
  const [lightboxImage, setLightboxImage] = useState<{ src: string; title: string } | null>(null);
  const [contactOpen, setContactOpen] = useState<boolean>(false);

  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleInspectProofById = (evidenceId: string) => {
    const found = PROOF_EVIDENCE_ITEMS.find((e) => e.id === evidenceId);
    if (found) {
      setInspectEvidence(found);
    }
  };

  const handleOpenImageLightbox = (src: string, title: string) => {
    setLightboxImage({ src, title });
  };

  return (
    <div className="min-h-screen bg-[#0b0b0e] text-[#e5e5eb] selection:bg-[#5c1424] selection:text-white relative">
      {/* Navigation */}
      <Navbar
        onOpenContact={() => setContactOpen(true)}
        onNavigateSection={handleNavigateSection}
      />

      {/* Main Content Sections */}
      <main>
        {/* 1. Hero */}
        <Hero
          onViewWork={() => handleNavigateSection('work')}
          onOpenContact={() => setContactOpen(true)}
        />

        {/* 2. Selected Work */}
        <SelectedWork
          projects={PROJECTS}
          onSelectProject={(project) => setSelectedProject(project)}
          onInspectProof={handleInspectProofById}
        />

        {/* 3. Featured Case Study */}
        <FeaturedCaseStudy
          project={PROJECTS[0]}
          onOpenCaseStudy={(project) => setSelectedProject(project)}
          onInspectProof={(ev) => setInspectEvidence(ev)}
          onOpenImageLightbox={handleOpenImageLightbox}
        />

        {/* 4. More Work */}
        <MoreWork
          projects={PROJECTS}
          onSelectProject={(project) => setSelectedProject(project)}
        />

        {/* 5. What I Do */}
        <WhatIDo />

        {/* 6. The Approach */}
        <TheApproach />

        {/* 7. Proof / Credibility ("The Work Speaks For Itself") */}
        <ProofCredibility
          onInspectProof={(ev) => setInspectEvidence(ev)}
        />

        {/* 8. About Ascend */}
        <AboutSection
          onOpenContact={() => setContactOpen(true)}
        />

        {/* 9. Final CTA */}
        <FinalCTA
          onOpenContact={() => setContactOpen(true)}
        />
      </main>

      {/* Footer */}
      <Footer
        onNavigateSection={handleNavigateSection}
        onOpenContact={() => setContactOpen(true)}
      />

      {/* Modals & Overlays */}
      <CaseStudyModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onInspectProof={(ev) => setInspectEvidence(ev)}
        onOpenImageLightbox={handleOpenImageLightbox}
        onOpenContact={() => setContactOpen(true)}
      />

      <LightboxModal
        evidence={inspectEvidence}
        imageSrc={lightboxImage?.src}
        imageTitle={lightboxImage?.title}
        onClose={() => {
          setInspectEvidence(null);
          setLightboxImage(null);
        }}
      />

      <ContactModal
        isOpen={contactOpen}
        onClose={() => setContactOpen(false)}
      />
    </div>
  );
}
