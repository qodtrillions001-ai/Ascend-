export interface MetricItem {
  label: string;
  value: string;
  verifiedSource: string;
  detail?: string;
}

export interface ProofEvidence {
  id: string;
  type: 'steamworks' | 'traffic_analytics' | 'campaign_crm' | 'client_review';
  title: string;
  subtitle: string;
  sourceLabel: string;
  date?: string;
  metricHighlight?: string;
  data: Record<string, any>;
}

export interface Project {
  id: string;
  title: string;
  appId?: string;
  genre: string;
  tagline: string;
  heroImage: string;
  fallbackImage?: string;
  campaignType: string;
  primaryResult: string;
  secondaryResult?: string;
  overview: string;
  approach: string;
  execution: string;
  resultsSummary: string;
  metrics: MetricItem[];
  proofId: string;
  steamUrl?: string;
  additionalProofIds?: string[];
}

export interface ClientReview {
  username: string;
  avatarLetter: string;
  avatarColor: string;
  rating: number;
  message: string;
  ratings?: {
    communication: number;
    quality: number;
    value: number;
  };
  highlights?: string[];
  role?: string;
}
